# Piñata Party
This is a application for sales in party shops. It can show 3D models of piñatas, accesories, cakes and other objects. This help to saleman to show a preview to client.